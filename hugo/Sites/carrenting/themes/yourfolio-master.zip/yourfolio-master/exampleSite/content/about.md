---
title: About me
date: 2017-11-08T16:56:15+02:00
draft: false
description: Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores porro voluptas esse natus nemo aperiam asperiores velit neque, magni molestiae!
header:
  description: I'm a multidisciplinary designer who specializing in <span class="accent-text">UI, UX and Visual Design</span>. Currently based in United Kingdom.
  image:
    url: about-hero.png
    alt: The designer's workspace table image
    media: "(max-width: 46.25em)"
    params:
    - options: 1130x500 jpg
    - options: 848x443 Center jpg
    - options: 700x420 Center jpg
    - options: 490x318 Center jpg
text_groups:
  - name: About
    description: Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facilis saepe perferendis culpa aut libero, <span class="default-text bold-text">voluptatem voluptatum</span>, ut beatae ipsa sint alias autem ipsum ea quibusdam suscipit provident illo nihil nostrum porro. Omnis et hic eum in corrupti dicta cum fugiat!
  - name: Philosophy
    description: Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus incidunt autem quia aliquid officia temporibus saepe ut quas nesciunt dolorum odio optio perspiciatis rem accusamus expedita nemo quis, fuga voluptatem. Corrupti vero asperiores officia, ipsa ipsam. Suscipit repellendus molestias, sint quas voluptates quia vitae quidem.
  - name: Disciplines
    description: <p>Lorem ipsum.</p><p>Officia, aliquam?</p><p>Dicta, quia?</p><p>Aliquid, excepturi!</p>
  - name: Get in touch
    description: <a class="accent-text bold-text" href="mailto:hello@example.com?subject=Hello,%20Yates!%20Lets%20make%20something%20great%20together!">hello@example.com</a>
    class: line
---


